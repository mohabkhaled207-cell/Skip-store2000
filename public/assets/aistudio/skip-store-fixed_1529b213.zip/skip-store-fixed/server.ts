import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// This server only serves the website (dev: Vite middleware, production: the built `dist` folder).
// All store data lives in Firebase Firestore and is read/written directly from the browser,
// so there is no /api/state, no local JSON file and no download endpoint here anymore.
async function startServer() {
  const app = express();
  // AI Studio requires the dev server to run on port 3000 (nginx proxy runs on 8080)
  const PORT = 3000;
  const isProduction = process.env.NODE_ENV === 'production';

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist/index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://localhost:${PORT}`);
  });
}

startServer();
