import { initializeApp } from 'firebase/app';
import { getAuth, signInWithEmailAndPassword, signOut, onAuthStateChanged, type User } from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  collection,
  getDocsFromServer,
  onSnapshot,
  getDocFromServer,
  writeBatch,
  setDoc,
  deleteDoc,
  updateDoc,
  query,
  orderBy,
  setLogLevel,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { StoreState, StoreSettings, Product } from './store';

// Suppress internal Firestore SDK verbose logging to prevent console pollution
try {
  setLogLevel('silent');
} catch {}

if (typeof window !== 'undefined') {
  const originalConsoleError = console.error;
  console.error = (...args: any[]) => {
    const str = args.map((a) => (a instanceof Error ? a.message : String(a))).join(' ');
    if (
      str.includes('RESOURCE_EXHAUSTED') ||
      str.includes('Quota limit exceeded') ||
      str.includes('quota metric') ||
      str.includes('Free daily write units') ||
      str.includes('Using maximum backoff delay') ||
      str.includes('GrpcConnection RPC')
    ) {
      markQuotaExceeded();
      return;
    }
    originalConsoleError.apply(console, args);
  };
}

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const ADMIN_EMAIL = 'skipstore27@gmail.com';
export function observeAuth(callback: (user: User | null) => void) {
  return onAuthStateChanged(auth, callback);
}
export async function loginAdmin(email: string, password: string): Promise<User> {
  const credential = await signInWithEmailAndPassword(auth, email.trim().toLowerCase(), password);
  if ((credential.user.email || '').toLowerCase() !== ADMIN_EMAIL) {
    await signOut(auth);
    throw new Error('هذا الحساب غير مصرح له بإدارة المتجر');
  }
  return credential.user;
}
export async function logoutAdmin(): Promise<void> {
  await signOut(auth);
}


export function getFirestoreConsoleUrl(): string {
  return `https://console.firebase.google.com/project/${firebaseConfig.projectId}/firestore/databases/${firebaseConfig.firestoreDatabaseId}/data?openUpgradeDialog=true`;
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

const QUOTA_STORAGE_KEY = 'skip_firestore_quota_until';
let quotaExceededState = false;

// Safe promise timeout wrapper that never rejects or hangs
function withTimeout<T>(promise: Promise<T>, ms: number, fallback: T): Promise<T> {
  let timer: any;
  const timeoutPromise = new Promise<T>((resolve) => {
    timer = setTimeout(() => resolve(fallback), ms);
  });
  return Promise.race([
    promise.then((res) => {
      clearTimeout(timer);
      return res;
    }),
    timeoutPromise,
  ]).catch(() => {
    clearTimeout(timer);
    return fallback;
  });
}

export function isFirestoreQuotaExceeded(): boolean {
  if (quotaExceededState) return true;
  if (typeof window !== 'undefined') {
    try {
      const untilStr = localStorage.getItem(QUOTA_STORAGE_KEY);
      if (untilStr) {
        const until = Number(untilStr);
        if (Date.now() < until) {
          quotaExceededState = true;
          return true;
        } else {
          localStorage.removeItem(QUOTA_STORAGE_KEY);
          quotaExceededState = false;
        }
      }
    } catch {}
  }
  return false;
}

export function markQuotaExceeded(): void {
  quotaExceededState = true;
  if (typeof window !== 'undefined') {
    try {
      const twelveHours = 12 * 60 * 60 * 1000;
      localStorage.setItem(QUOTA_STORAGE_KEY, String(Date.now() + twelveHours));
    } catch {}
  }
}

export function isQuotaExceededError(error: unknown): boolean {
  if (!error) return false;
  const msg = error instanceof Error ? error.message : String(error);
  const exceeded = (
    msg.includes('resource-exhausted') ||
    msg.includes('RESOURCE_EXHAUSTED') ||
    msg.includes('Quota limit exceeded') ||
    msg.includes('quota limits') ||
    msg.includes('quota metric') ||
    msg.includes('GrpcConnection RPC') ||
    msg.includes('maximum backoff delay')
  );
  if (exceeded) {
    markQuotaExceeded();
  }
  return exceeded;
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  if (isQuotaExceededError(error)) {
    return;
  }
  const errInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: null,
      email: null,
      emailVerified: null,
      isAnonymous: null,
      tenantId: null,
      providerInfo: [],
    },
    operationType,
    path,
  };
  console.warn('Firestore Notice: ', JSON.stringify(errInfo));
}

export async function testConnection() {
  if (isFirestoreQuotaExceeded()) return;
  try {
    await withTimeout(getDocFromServer(doc(db, 'test', 'connection')), 1500, null);
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn("Please check your Firebase configuration.");
    } else if (isQuotaExceededError(error)) {
      markQuotaExceeded();
    }
  }
}

// Fetch the authoritative store state directly from the Firestore server.
export async function getStoreStateFromFirestore(): Promise<StoreState | null> {
  try {
    const settingsSnap = await getDocFromServer(doc(db, 'store_config', 'settings'));
    if (!settingsSnap.exists()) return null;

    const settingsData = settingsSnap.data();
    if (!settingsData.settings) return null;

    const productsSnap = await getDocsFromServer(collection(db, 'products'));
    const products: Product[] = productsSnap.docs.map((productDoc) => ({
      ...(productDoc.data() as Product),
      id: productDoc.id,
    }));

    return {
      v: 1,
      updatedAt: Number(settingsData.updatedAt || 0),
      settings: settingsData.settings as StoreSettings,
      products,
    };
  } catch (error) {
    if (!isQuotaExceededError(error)) handleFirestoreError(error, OperationType.GET, 'store_config/settings');
    throw error;
  }
}

// Delete a product directly and atomically from Firestore.
export async function deleteProductFromFirestore(productId: string, newUpdatedAt: number): Promise<boolean> {
  if (isFirestoreQuotaExceeded()) throw new Error('Firestore quota limit reached');
  try {
    const batch = writeBatch(db);
    batch.delete(doc(db, 'products', productId));
    batch.set(doc(db, 'store_config', 'settings'), { updatedAt: newUpdatedAt }, { merge: true });
    batch.delete(doc(db, 'store_config', 'latest'));
    await batch.commit(); // Resolves only after Firestore acknowledges the write.
    return true;
  } catch (error) {
    if (!isQuotaExceededError(error)) handleFirestoreError(error, OperationType.DELETE, `products/${productId}`);
    throw error;
  }
}

// Save the complete store state and reconcile products in one acknowledged batch.
export async function saveStoreStateToFirestore(state: StoreState): Promise<boolean> {
  if (isFirestoreQuotaExceeded()) throw new Error('Firestore quota limit reached');
  try {
    const batch = writeBatch(db);
    const now = state.updatedAt || Date.now();
    batch.set(doc(db, 'store_config', 'settings'), {
      settings: state.settings,
      updatedAt: now,
      v: state.v || 1,
    });

    // Reconcile the complete products collection in the same acknowledged batch.
    const existingSnap = await getDocsFromServer(collection(db, 'products'));
    const incomingIds = new Set(state.products.map((product) => product.id));
    existingSnap.forEach((productDoc) => {
      if (!incomingIds.has(productDoc.id)) batch.delete(productDoc.ref);
    });
    state.products.forEach((product) => {
      if (!product.id) throw new Error('A product is missing its Firestore document ID');
      batch.set(doc(db, 'products', product.id), product);
    });
    batch.delete(doc(db, 'store_config', 'latest'));

    await batch.commit(); // Never report success before Firestore confirms the commit.
    return true;
  } catch (error) {
    if (!isQuotaExceededError(error)) handleFirestoreError(error, OperationType.WRITE, 'store_config/settings');
    throw error;
  }
}

// Real-time listener across settings and products collection
export function subscribeToStoreState(
  onUpdate: (state: StoreState) => void,
  onError?: (err: unknown) => void
) {
  let currentSettings: StoreSettings | null = null;
  let currentUpdatedAt = 0;
  let currentProductsMap: Map<string, Product> | null = null;

  const emit = () => {
    if (currentSettings && currentProductsMap !== null) {
      onUpdate({
        v: 1,
        updatedAt: currentUpdatedAt,
        settings: currentSettings,
        products: Array.from(currentProductsMap.values()),
      });
    }
  };

  try {
    const unsubSettings = onSnapshot(
      doc(db, 'store_config', 'settings'),
      (snap) => {
        if (snap.exists()) {
          const data = snap.data();
          if (data.settings) {
            currentSettings = data.settings;
            currentUpdatedAt = Math.max(currentUpdatedAt, data.updatedAt || 0);
            emit();
          }
        }
      },
      (error) => {
        if (isQuotaExceededError(error)) {
          // quota marked
        } else if (onError) {
          onError(error);
        }
      }
    );

    const unsubProducts = onSnapshot(
      collection(db, 'products'),
      (snap) => {
        const newMap = new Map<string, Product>();
        snap.forEach((dSnap) => {
          newMap.set(dSnap.id, { ...(dSnap.data() as Product), id: dSnap.id });
        });
        currentProductsMap = newMap;
        emit();
      },
      (error) => {
        if (isQuotaExceededError(error)) {
          // quota marked
        } else if (onError) {
          onError(error);
        }
      }
    );

    return () => {
      try {
        unsubSettings();
        unsubProducts();
      } catch {}
    };
  } catch (err) {
    if (isQuotaExceededError(err)) {
      // quota marked
    }
    return () => {};
  }
}


// Orders and activity are stored in Firestore as well, with live listeners.
export async function recordActivity(item: import('./store').ActivityItem): Promise<void> {
  await setDoc(doc(db, 'activity', item.id), item);
}

export function subscribeToActivity(callback: (items: import('./store').ActivityItem[]) => void) {
  return onSnapshot(query(collection(db, 'activity'), orderBy('timestamp', 'desc')), (snap) => {
    callback(snap.docs.map((d) => d.data() as import('./store').ActivityItem));
  }, (error) => handleFirestoreError(error, OperationType.LIST, 'activity'));
}

export async function saveOrderToFirestore(order: import('./store').CustomerOrder): Promise<void> {
  await setDoc(doc(db, 'orders', order.id), order);
}

export function subscribeToOrders(callback: (items: import('./store').CustomerOrder[]) => void) {
  return onSnapshot(query(collection(db, 'orders'), orderBy('createdAt', 'desc')), (snap) => {
    callback(snap.docs.map((d) => d.data() as import('./store').CustomerOrder));
  }, (error) => handleFirestoreError(error, OperationType.LIST, 'orders'));
}

export async function updateOrderStatusInFirestore(orderId: string, status: import('./store').CustomerOrder['status']): Promise<void> {
  const orderRef = doc(db, 'orders', orderId);
  const snap = await getDoc(orderRef);
  if (!snap.exists()) throw new Error('الطلب غير موجود');
  await updateDoc(orderRef, { status });
}

export async function deleteOrderFromFirestore(orderId: string): Promise<void> {
  await deleteDoc(doc(db, 'orders', orderId));
}
