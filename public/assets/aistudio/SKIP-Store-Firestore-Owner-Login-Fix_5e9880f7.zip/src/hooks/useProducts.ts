import { useEffect, useState } from "react";
import { Product } from "../utils/store";
import { subscribeToStoreState } from "../utils/firebase";

// Read-only live products hook. All writes must go through the authenticated
// Firestore transaction/save flow used by the owner dashboard.
export function useProducts() {
  const [products, setProducts] = useState<Product[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const unsubscribe = subscribeToStoreState((state) => {
      setProducts(state.products);
      setReady(true);
    });
    return () => unsubscribe();
  }, []);

  return { products, ready };
}
