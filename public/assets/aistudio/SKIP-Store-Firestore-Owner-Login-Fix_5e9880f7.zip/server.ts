import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  // AI Studio requires the dev server to run on port 3000 (nginx proxy runs on 8080)
  const PORT = 3000;
  const isProduction = process.env.NODE_ENV === 'production';
  app.use(express.json({ limit: '50mb' }));

  // Store products and settings are read and written directly by the Firebase client SDK.
  // The legacy server-side JSON mirror is intentionally disabled to prevent stale restores.
  app.get('/api/state', (_req, res) => {
    res.status(410).json({ error: 'Legacy state endpoint disabled. Use Firestore.' });
  });
  app.post('/api/state', (_req, res) => {
    res.status(410).json({ error: 'Legacy state endpoint disabled. Use Firestore.' });
  });

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist/index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://localhost:${PORT}`);
  });
}

startServer();
