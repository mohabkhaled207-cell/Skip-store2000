import { initializeApp } from 'firebase/app';
import {
  getAuth,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut,
  type User,
} from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getFirestore,
  initializeFirestore,
  memoryLocalCache,
  onSnapshot,
  setDoc,
  writeBatch,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import type { Product, StoreSettings } from './store';

/**
 * Firestore is the ONLY source of truth for this store.
 * - No localStorage, no server-side JSON file, no bundled default data is ever shown to customers.
 * - Reads: real-time listeners (onSnapshot) so every change reaches customers immediately.
 * - Writes: one document at a time, and every write is awaited until the server confirms it.
 */

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);

// memoryLocalCache = nothing is persisted in the browser, data always comes from the server.
function createDb() {
  try {
    return initializeFirestore(app, { localCache: memoryLocalCache() }, firebaseConfig.firestoreDatabaseId);
  } catch {
    // Already initialised (e.g. during hot reload) – reuse the existing instance.
    return getFirestore(app, firebaseConfig.firestoreDatabaseId);
  }
}

export const db = createDb();

const SETTINGS_COLLECTION = 'store_config';
const SETTINGS_DOC = 'settings';
const PRODUCTS_COLLECTION = 'products';

/** A Firestore document is limited to 1 MiB; images are stored as data URLs inside the document. */
export const MAX_IMAGE_CHARS = 900_000;

/** How long we wait for the server to confirm a write before telling the owner it is NOT confirmed. */
const SAVE_TIMEOUT_MS = 15_000;

// ---------------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------------

export class SaveError extends Error {
  constructor(public readonly reason: 'timeout' | 'image-too-large') {
    super(reason);
    this.name = 'SaveError';
  }
}

export function describeFirestoreError(err: unknown): string {
  if (err instanceof SaveError) {
    if (err.reason === 'image-too-large') {
      return 'الصورة كبيرة قوي على قاعدة البيانات. اختار صورة أصغر.';
    }
    return 'مقدرناش نأكد الحفظ على Firestore خلال 15 ثانية. اتأكد من النت أو إن الحصة اليومية المجانية في Firebase لسه ما خلصتش، وبعدين جرّب تاني.';
  }

  const code = String((err as { code?: unknown } | null)?.code ?? '');
  const message = String((err as { message?: unknown } | null)?.message ?? err ?? '');

  if (code.includes('permission-denied')) {
    return 'مفيش صلاحية للحفظ. تأكد إنك داخل بإيميل صاحب الستور وإن قواعد Firestore (firestore.rules) اتنشرت.';
  }
  if (code.includes('unauthenticated')) {
    return 'الجلسة انتهت. سجّل دخول تاني.';
  }
  if (code.includes('resource-exhausted') || /quota/i.test(message)) {
    return 'الحصة اليومية المجانية للكتابة في Firebase خلصت. بتتجدد تلقائيًا كل يوم.';
  }
  if (code.includes('unavailable') || code.includes('network')) {
    return 'مفيش اتصال بقاعدة البيانات دلوقتي. اتأكد من النت وجرّب تاني.';
  }
  return `الحفظ ماتمش${code ? ` (${code})` : ''}. جرّب تاني.`;
}

export function describeLoadError(err: unknown): string {
  const code = String((err as { code?: unknown } | null)?.code ?? '');
  if (code.includes('permission-denied')) {
    return 'مفيش صلاحية لقراءة بيانات الستور. قواعد Firestore (firestore.rules) محتاجة تتنشر.';
  }
  if (code.includes('resource-exhausted')) {
    return 'الحصة اليومية المجانية للقراءة في Firebase خلصت. بتتجدد تلقائيًا كل يوم.';
  }
  return 'تعذّر تحميل بيانات الستور من قاعدة البيانات. اتأكد من النت وجرّب تاني.';
}

export function describeAuthError(err: unknown): string {
  const code = String((err as { code?: unknown } | null)?.code ?? '');
  switch (code) {
    case 'auth/invalid-email':
      return 'الإيميل مكتوب غلط.';
    case 'auth/invalid-credential':
    case 'auth/wrong-password':
    case 'auth/user-not-found':
    case 'auth/invalid-login-credentials':
      return 'الإيميل أو الباسورد غير صحيح.';
    case 'auth/user-disabled':
      return 'الحساب ده متوقف.';
    case 'auth/too-many-requests':
      return 'محاولات كتير غلط. استنى شوية وجرّب تاني.';
    case 'auth/network-request-failed':
      return 'مفيش اتصال بالإنترنت.';
    case 'auth/operation-not-allowed':
      return 'تسجيل الدخول بالإيميل والباسورد مش متفعّل في Firebase (Authentication ← Sign-in method).';
    default:
      return 'تعذّر تسجيل الدخول. جرّب تاني.';
  }
}

// ---------------------------------------------------------------------------
// Owner authentication (Firebase Authentication – email + password)
// ---------------------------------------------------------------------------

export function subscribeToAuth(onChange: (user: User | null) => void): () => void {
  return onAuthStateChanged(auth, onChange);
}

export async function ownerSignIn(email: string, password: string): Promise<User> {
  const credential = await signInWithEmailAndPassword(auth, email.trim(), password);
  return credential.user;
}

export function ownerSignOut(): Promise<void> {
  return signOut(auth);
}

// ---------------------------------------------------------------------------
// Reading – real-time
// ---------------------------------------------------------------------------

export interface LiveStore {
  /** null when /store_config/settings does not exist yet (empty database). */
  settings: StoreSettings | null;
  products: Product[];
  /** true while a local write has not been confirmed by the server yet. */
  hasPendingWrites: boolean;
}

/** Newest first (by createdAt); products without createdAt keep a stable order by id after the newer ones. */
export function sortProducts(products: Product[]): Product[] {
  return [...products].sort((a, b) => {
    const diff = (b.createdAt ?? 0) - (a.createdAt ?? 0);
    if (diff !== 0) return diff;
    return a.id.localeCompare(b.id, 'en', { numeric: true });
  });
}

export function subscribeToStore(
  onData: (store: LiveStore) => void,
  onError: (err: unknown) => void
): () => void {
  let settings: StoreSettings | null = null;
  let settingsReady = false;
  let settingsPending = false;
  let products: Product[] = [];
  let productsReady = false;
  let productsPending = false;

  const emit = () => {
    if (!settingsReady || !productsReady) return;
    onData({
      settings,
      products: sortProducts(products),
      hasPendingWrites: settingsPending || productsPending,
    });
  };

  const unsubscribeSettings = onSnapshot(
    doc(db, SETTINGS_COLLECTION, SETTINGS_DOC),
    (snap) => {
      // An empty answer that comes from the (empty) local cache is not an answer from the server.
      if (snap.metadata.fromCache && !snap.exists() && !settingsReady) return;
      const data = snap.exists() ? snap.data() : null;
      settings = data && data.settings ? (data.settings as StoreSettings) : null;
      settingsPending = snap.metadata.hasPendingWrites;
      settingsReady = true;
      emit();
    },
    onError
  );

  const unsubscribeProducts = onSnapshot(
    collection(db, PRODUCTS_COLLECTION),
    (snap) => {
      if (snap.metadata.fromCache && snap.empty && !productsReady) return;
      products = snap.docs.map((d) => ({ ...(d.data() as Product), id: d.id }));
      productsPending = snap.metadata.hasPendingWrites;
      productsReady = true;
      emit();
    },
    onError
  );

  return () => {
    unsubscribeSettings();
    unsubscribeProducts();
  };
}

// ---------------------------------------------------------------------------
// Writing – every function resolves ONLY after Firestore confirmed the write
// ---------------------------------------------------------------------------

function confirmed<T>(operation: Promise<T>): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => reject(new SaveError('timeout')), SAVE_TIMEOUT_MS);
    operation.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      (error) => {
        clearTimeout(timer);
        reject(error);
      }
    );
  });
}

/** Firestore rejects `undefined` values, so strip them. */
function plain<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T;
}

function assertImageFits(image: string | undefined) {
  if (image && image.length > MAX_IMAGE_CHARS) throw new SaveError('image-too-large');
}

/** Creates or updates ONE product document (never rewrites the whole catalogue). */
export async function saveProduct(product: Product): Promise<void> {
  assertImageFits(product.image);
  await confirmed(
    setDoc(doc(db, PRODUCTS_COLLECTION, product.id), plain({ ...product, updatedAt: Date.now() }))
  );
}

export async function deleteProduct(productId: string): Promise<void> {
  await confirmed(deleteDoc(doc(db, PRODUCTS_COLLECTION, productId)));
}

export async function saveSettings(settings: StoreSettings): Promise<void> {
  assertImageFits(settings.logo);
  await confirmed(
    setDoc(doc(db, SETTINGS_COLLECTION, SETTINGS_DOC), plain({ settings, updatedAt: Date.now(), v: 1 }))
  );
}

/** One-time initial data for an empty database (owner only, triggered manually). */
export async function seedStore(settings: StoreSettings, products: Product[]): Promise<void> {
  const batch = writeBatch(db);
  const now = Date.now();
  batch.set(doc(db, SETTINGS_COLLECTION, SETTINGS_DOC), plain({ settings, updatedAt: now, v: 1 }));
  for (const product of products) {
    assertImageFits(product.image);
    batch.set(doc(db, PRODUCTS_COLLECTION, product.id), plain({ ...product, updatedAt: now }));
  }
  await confirmed(batch.commit());
}
